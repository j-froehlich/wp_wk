<div class="row" style="margin-top: 40px;">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">Welcome!</h3>
            </div>
            <div class="panel-body">
                First of all, Thanks for using our product! <br />
                Wiloke Service is bridge between Wiloke Service and your site, in order to provide better customer service. We're going to build lots of features, and this plugin will assist you to ingrate those into your site easily.
            </div>
        </div>

        <div id="wiloke-service-wrapper">
            <div class="well bs-component">
                <legend><?php esc_html_e('Just one last step to activate Wiloke Service', 'wiloke-service'); ?></legend>
                <?php if ( $alert = get_option(WilokeService::$wilokeServiceError) ) :  ?>
                    <p class="help-block"><?php echo esc_html($alert); ?></p>
                <?php endif; ?>
                <form method="POST">
                    <?php wp_nonce_field('wiloke-update-nonce', 'wiloke-update-action'); ?>
                    <fieldset>
                        <div class="form-group">
                          <label for="token-secret" class="col-lg-2 control-label"><?php esc_html_e('Access Token', 'wiloke-service'); ?></label>
                          <div class="col-lg-10">
                            <textarea class="form-control" rows="20" id="token-secret" name="wiloke_update[secret_token]"><?php echo esc_textarea($secretToken); ?></textarea>
                            <span class="help-block"><?php esc_html_e('Need help getting your Access Keys?', 'wiloke-service'); ?>  <a href="http://wiloke.net" target="_blank"><?php esc_html_e('Check out the Quick Start Guide →', 'wiloke-service'); ?></a></span>
                          </div>
                        </div>

                        <div class="form-group">
                          <div class="col-lg-10 col-lg-offset-2">
                            <button type="submit" name="submit" id="submit" class="btn btn-primary">Submit</button>
                          </div>
                        </div>

                    </fieldset>
                </form>
            </div>
        </div>

    </div>
</div>