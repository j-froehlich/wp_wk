;(function ($) {
    'use strict';

    $(document).ready(function () {
        $('#page-wrap .page-content').css({
            height: $(window).height()
        });
    })

})(jQuery);