/**
 * Created by pirates on 12/10/15.
 */
;(function($, window, document, undefined){
    "use strict"

    //Adding Insert Sample Template button


    function setWilokeImportPanel(){
       
    }

    $(document).ready(function () {
        
    })

})(jQuery, window, document);