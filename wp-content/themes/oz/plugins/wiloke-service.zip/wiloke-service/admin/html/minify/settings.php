<div class="well bs-component col-md-8 col-md-offset-2">
    <fieldset>
        <legend><?php esc_html_e('Minify Settings', 'wiloke-service'); ?></legend>
		<i><?php esc_html_e('Comporess all theme\'s scripts into one file, it\'s help to speed up. We highly recommend using this feature.', 'wiloke-service'); ?></i>

        <form style="margin-top: 20px;" id="wiloke-compress-settings" class="form-horizontal" action="<?php echo esc_url(admin_url('admin.php?page='.WilokeService::$aSlug['minify'])); ?>" method='POST' data-homeurl="<?php echo esc_url(get_option('home')); ?>">
            <?php wp_nonce_field('wiloke_minify_action', 'wiloke_minify_nonce'); ?>
            <div class="form-group">
                <div class="col-lg-10">
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name="wiloke_minify[javascript]" value="1" <?php checked($aData['javascript'], 1); ?> /> Minify JavaScripts
                        </label>
                    </div>
                </div>
                <div class="col-lg-10">
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name="wiloke_minify[css]" value="1" <?php checked($aData['css'], 1); ?> /> Minify CSS
                        </label>
                    </div>
                </div>
            </div>

            <div class="form-group" style="margin-top: 20px;">
                <div class="col-lg-10">
                    <button type="submit" class="button-save btn btn-primary"><?php esc_html_e('Compress', 'wiloke-service'); ?></button>
                </div>
            </div>
        </form>
    </fieldset>
</div>