<?php
/**
 * Wiloke Notification
 * Notification for user know what changed and what updated
 *
 * @link        https://wiloke.com
 * @since       0.5
 * @package     WilokeService
 * @subpackage  WilokeService/admin
 * @author      Wiloke
 */

if ( !defined('ABSPATH') )
{
    wp_die( esc_html__('You do not permission to access to this page', 'wiloke-service') );
}

if ( !class_exists('WilokeNotification') )
{
    class WilokeNotification{

        public function __construct()
        {
            add_action('admin_footer', array($this, 'render_notifications'));
            add_action('wp_ajax_wiloke_service_read_notification', array($this, 'read_notification'));
        }

        public function read_notification(){
            check_ajax_referer(WilokeService::$nonceKey, 'security');
            delete_option(WilokeService::$hasUpdateKey);
            wp_send_json_success();
        }

        /**
         * Enqueue Script
         * @since 0.6
         */
        public function enqueue_scripts(){
            wp_enqueue_style('wiloke-notification', plugin_dir_url( dirname(__FILE__) ) . 'source/css/notification.css');
            wp_enqueue_script('wiloke-notification', plugin_dir_url( dirname(__FILE__) ) . 'source/js/notification.js', array('jquery'), null, true);
        }

        /**
         * Render Notification
         * @since 0.6
         */
        public function render_notifications(){
            if ( !is_admin() ){
                return;
            }
        ?>
            <div class="wil-noti">
                <div class="wil-noti-header">
                    <h4>Wiloke center</h4>
                    <i class="dashicons dashicons-no wil-exit"></i>
                </div>
                <ul class="wil-noti-list">
                    <?php
                    $this->theme_notifications();
                    $this->plugins_notifications();
                    ?>
                </ul>
            </div>

            <div class="wil-noti-show-icon <?php if(get_option(WilokeService::$hasUpdateKey)) {
                echo esc_attr('animation');
            } ?>">
                <i class="dashicons dashicons-universal-access"></i>
            </div>
        <?php
        }

        /**
         * Plugin Notification
         * @since 0.6
         */
        public function plugins_notifications(){
            $aLogs = get_transient(WilokeService::$WilokeUpdate->get_option_name('wiloke_update_plugins'));
            if ( !empty($aLogs) ) {
                foreach ( $aLogs as $aLog ) {
                    if ( !empty($aLog['description']) ) :
                        ?>
                        <li>
                            <?php $this->title($aLog['plugin']); ?>
                            <?php $this->item($aLog['description']); ?>
                        </li>
                        <?php
                    endif;
                }
            }
        }

        /**
         * Theme Notification
         * @since 0.6
         */
        public function theme_notifications(){
            $aLogs = get_transient(WilokeService::$WilokeUpdate->get_option_name('wiloke_update_themes'));
            $slug = isset(WilokeService::$aThemeInfo['slug']) ? WilokeService::$aThemeInfo['slug'] : get_template();

            if ( isset($aLogs[$slug]) && !empty($aLogs[$slug]) ) {
                if ( !empty($aLogs[$slug]['description']) ) :
                    ?>
                    <li>
                        <?php $this->title($aLogs[$slug]['slug']); ?>
                        <?php $this->item($aLogs[$slug]['description']); ?>
                    </li>
                    <?php
                endif;
            }
        }

        /**
         * Notification Title
         * @since 0.6
         */
        public function title($title){
            ?>
            <h4 class="wil-noti-name"><?php esc_html_e(ucfirst($title)); ?></h4>
            <?php
        }

        public function item($item){
            ?>
            <p class="wil-noti-mess"><?php echo $item; ?></p>
            <?php
        }


    }
}