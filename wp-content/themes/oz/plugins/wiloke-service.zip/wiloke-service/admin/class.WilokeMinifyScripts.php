<?php
/**
 * WilokeMinifyScripts
 * Speed up website
 *
 * @link        https://wiloke.com
 * @since       0.6
 * @package     WilokeService
 * @subpackage  WilokeService/admin
 * @author      Wiloke
 */

use MatthiasMullie\Minify;

if ( !defined('ABSPATH') )
{
    wp_die( esc_html__('You do not permission to access to this page', 'wiloke-service') );
}

if ( !class_exists('WilokeMinifyScripts') ) {

    class WilokeMinifyScripts
    {
		public $aListOfScripts;
		public $aIgnoreScrips = array(
			'/wp-includes/js/admin-bar.js',
			'/wp-includes/js/admin-bar.min.js',
			'/wp-includes/css/admin-bar.css',
			'/wp-includes/css/admin-bar.min.css',
			'/wp-includes/js/quicktags.js',
			'/wp-includes/js/quicktags.min.js',
			'/wp-admin/js/editor.js',
			'/wp-admin/js/editor.min.js',
			'/wp-includes/js/wp-ajax-response.js',
			'/wp-includes/js/wp-ajax-response.min.js',
			'/wp-includes/js/wp-pointer.js',
			'/wp-includes/js/wp-pointer.min.js',
			'/wp-includes/js/autosave.js',
			'/wp-includes/js/autosave.min.js',
			'/wp-includes/js/heartbeat.js',
			'/wp-includes/js/heartbeat.min.js',
			'/wp-includes/js/wp-lists.js',
			'/wp-includes/js/wp-lists.min.js',
			'/wp-admin/js/wp-fullscreen-stub.js',
			'/wp-admin/js/wp-fullscreen-stub.min.js',
			'/wp-includes/js/crop/cropper.min.js',
			'/wp-includes/js/crop/cropper.js',
			'/wp-includes/js/crop/cropper.min.js',
//			'/wp-includes/js/jquery/jquery.js',
			'wp-includes/js/jquery/jquery-migrate.min.js',
			'wp-includes/js/jquery/jquery-migrate.js'
		);
		public $aListOfCss;
		public $aStatus;
		private $_recreateFileKey = '_wiloke_minify_recreate_minify';
		public $scriptPrefix = 'wiloke_minify_';

		public function alert_recompress_scripts(){
			update_option($this->_recreateFileKey, 1);
		}

		public function init(){
			$this->aStatus = get_option('_wiloke_minify');
		}

		public function wp_enqueue_scripts(){
			if ( $this->aStatus && !get_option($this->_recreateFileKey) ){
				$jsFileName  = get_option('wiloke_minify_theme_js');
				$cssFileName = get_option('wiloke_minify_theme_css');

				$aUploadInfo = wp_upload_dir();
				$uploadUrl   = $aUploadInfo['baseurl'] . '/';

				if (  isset($this->aStatus['javascript']) && !empty($this->aStatus['javascript']) ) {
					$this->aListOfScripts = get_option('_wiloke_minify_list_of_js');
					if (!empty($this->aListOfScripts)) {
						foreach ($this->aListOfScripts as $handle => $script) {
							wp_dequeue_script($handle);
						}
					}
				}

				if (  isset($this->aStatus['css']) && !empty($this->aStatus['css']) ) {
					$this->aListOfCss = get_option('_wiloke_minify_list_of_css');
					if ( !empty($this->aListOfCss) ){
						foreach ($this->aListOfCss as $handle => $script){
							wp_dequeue_style($handle);
						}
					}
				}

				wp_enqueue_script('wiloke_minify_theme_js', $uploadUrl . $jsFileName, array('jquery'), null, true);
				wp_enqueue_style('wiloke_minify_theme_css', $uploadUrl . $cssFileName);
			}
		}

		public function parse_scripts(){
			if ( is_admin() ){
				return;
			}
			if ($this->aStatus){
				if ( get_option($this->_recreateFileKey) ) {
					global $wp_scripts, $wp_styles;
					$this->aListOfCss = $this->aListOfScripts = array();

					$isGenerate = false;
					if (current_user_can('edit_theme_options')) {
						foreach (array($wp_scripts, $wp_styles) as $dependencies) {
							if ($dependencies instanceof WP_Dependencies && !empty($dependencies->queue)) {
								foreach ($dependencies->queue as $handle) {
									if (!isset($dependencies->registered[$handle])) {
										continue;
									}
									/* @var _WP_Dependency $dependency */
									$dependency = $dependencies->registered[$handle];

									$parsed = wp_parse_url($dependency->src);
									if (!empty($parsed['host']) && ($parsed['host'] === $_SERVER['SERVER_NAME']) && (strpos($parsed['path'], $this->scriptPrefix) === false) && !in_array($parsed['path'], $this->aIgnoreScrips) && (strpos($parsed['path'], 'wiloke_minify_js_') === false) && (strpos($parsed['path'], 'wiloke_minify_css_') === false) && !strpos($parsed['path'], 'plugins/woocommerce/')  && (strpos($parsed['path'], '/'.get_option('stylesheet') . '/style.css') === false) ) {
										$isGenerate = true;
										if (strpos($parsed['path'], '.css') !== false) {
											$this->aListOfCss[$dependency->handle] = $parsed['path'];
										} else {
											$this->aListOfScripts[$dependency->handle] = $parsed['path'];
										}
									}
								}
							}
						}
					}

					if ($isGenerate) {
						$this->createMinifier();
						delete_option($this->_recreateFileKey);
					}
				}
			}
		}

		public function register_submenu()
	    {
	        add_submenu_page( WilokeService::$aSlug['main'], esc_html__('Minify Scripts', 'wiloke-service'), esc_html__('Minify Scripts', 'wiloke-service'), 'edit_theme_options', WilokeService::$aSlug['minify'], array($this, 'settings'));
	    }

	    public function jsDir($jsDir, $minifierJs){
			$minifierJs->add($jsDir);
			return $jsDir;
	    }

	    public function cssDir($cssDir, $minifierCss){
			$minifierCss->add($cssDir);
			return $cssDir;
	    }

	    public function settings(){
			$aData = get_option('_wiloke_minify');
			$aData = wp_parse_args($aData, array('css'=>0, 'javascript'=>0));
	    	include plugin_dir_path(__FILE__) . 'html/minify/settings.php';
	    }

		public function save_settings(){
			if ( check_ajax_referer('wiloke_minify_action', 'security', true) ){
				parse_str($_POST['data'], $aData);
				update_option('_wiloke_minify', $aData['wiloke_minify']);

				if ( empty($aData['wiloke_minify']['javascript']) && empty($aData['wiloke_minify']['css']) ){
					delete_option($this->_recreateFileKey);
					wp_send_json_error();
				}else{
					update_option($this->_recreateFileKey, 1);
				}

				wp_send_json_success();
			}

			wp_send_json_error();
		}

		public function getRealPath($path){
			if ( strpos($path, 'plugins') !== false ){
				$path = substr($path, strpos($path, '/plugins/'));
				$path = WP_PLUGIN_DIR . str_replace('plugins/', '', $path);
			}else{
				$path = substr($path, strpos($path, '/themes/'));
				$path = WP_CONTENT_DIR . '/themes' . str_replace('themes/', '', $path);
			}

			return $path;
		}

	    public function createMinifier(){
	    	if ( empty(WilokeService::$aThemeInfo) || strtolower(WilokeService::$aThemeInfo['author']) != 'wiloke' ) {
	    		return;
	    	}

	    	include plugin_dir_path(__FILE__) . 'minify-master/vendor/autoload.php';

	    	$uploadDir = wp_upload_dir();
			$uploadDir = $uploadDir['basedir'].'/';
			$minifierJs = new Minify\JS();
			$minifierCss = new Minify\CSS();

			update_option('_wiloke_minify_list_of_js', $this->aListOfScripts);
			update_option('_wiloke_minify_list_of_css', $this->aListOfCss);

	    	if ( !empty($this->aListOfScripts) ) {
				foreach ( $this->aListOfScripts as $dir ){
					$file = $this->getRealPath($dir);
					if ( is_file($file) ){
						$this->jsDir($file, $minifierJs);
					}
				}

	    		$fileName = 'wiloke_minify_js_'.trim(WilokeService::$aThemeInfo['name']).'_'.trim(WilokeService::$aThemeInfo['version']);
	    		
	    		if ( get_option('wiloke_minify_theme_js') && is_file(get_option('wiloke_minify_theme_js')) ){
	    			unlink(get_option('wiloke_minify_theme_js'));
	    		}

	    		$minifierJs->minify($uploadDir.$fileName.'.js');
	    		update_option('wiloke_minify_theme_js', $fileName.'.js');
	    	}

			if ( !empty($this->aListOfCss) ) {
				foreach ( $this->aListOfCss as $dir ){
					$file = $this->getRealPath($dir);
					if ( is_file($file) ){
						$this->cssDir($file, $minifierCss);
					}
				}

	    		$fileName = 'wiloke_minify_css_'.trim(WilokeService::$aThemeInfo['name']).'_'.trim(WilokeService::$aThemeInfo['version']);
	    		
	    		if ( get_option('wiloke_minify_theme_css') && is_file(get_option('wiloke_minify_theme_css')) ){
	    			unlink(get_option('wiloke_minify_theme_css'));
	    		}

	    		$minifierCss->minify($uploadDir.$fileName.'.css');
	    		update_option('wiloke_minify_theme_css', $fileName.'.css');
	    	}
	    }
    }
}